MODDIR="${0%/*}"
. "$MODDIR/util_functions.sh"

press_check 3 && disable_modules
