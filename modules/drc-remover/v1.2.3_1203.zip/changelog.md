## Change logs

#v1.2.3
* Added "compatible Magisk-mirroring" message for incompatible Magisk variants

# v1.2.2
* Added checking incompatible Magisk variants

# v1.2.1
* Added support for ColorOS (experimental)

# v1.2.0
* Fixed some SELinux related bugs for Magisk v26.0's new magic mount feature

# v1.1.0
* Fixed a bug on phh GSI's (unmounted in a boot process by phh GSI's)
* Added support for Xiaomi & OnePlus devices

# v1.0.0
* Initial Release

##
