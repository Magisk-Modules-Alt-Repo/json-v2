## Registro de cambios:

-2.0
	Corregido el error de toast en negro
	Ahora funciona en Miui 10-13
	Compatible con Android 8 y superior (12.1 compatible)

-1.0
    Versión inicial, compatible con Android 8 y superiores
    Probado en Android Miui 10-11-12
	
---

*ENGLISH VERSION*

---

## Changelog:

-2.0
	Fixed toast in black error
	Now works on Miui 10-13
	Compatible with Android 8 and higher (12.1 compatible)

-1.0 
    Initial version, compatible with Android 8 and higher
    Tested on Android Miui 10-11-12
