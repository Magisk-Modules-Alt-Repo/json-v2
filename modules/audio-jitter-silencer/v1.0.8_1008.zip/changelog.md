## Change logs

#v1.0.8
* Removed unnecessary files under $MODPATH

# v1.0.7
* Added other remaining all cutout app's to the doze white-list (I think this reduces jitter extremely even for superficially unused cutouts)
* Added KernekSU, Magisk alpha and Kitsune Magisk to the doze white-list

# v1.0.6
* Added Punch hole cutout to the doze white-list

# v1.0.5
* Tuned the doze whitelist for audio

# v1.0.4
* Changed to set battery optimizations to be disabled without fail

# v1.0.3
* Disabled the adaptive battery charging feature (esp. on Tensor devices)
* Added some apps into the doze white-list

# v1.0.0
* Initial Release

##
