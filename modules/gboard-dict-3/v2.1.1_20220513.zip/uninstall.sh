#!/system/bin/sh

rm /data/data/com.google.android.inputmethod.latin/files/user_dict_3_3.bak
