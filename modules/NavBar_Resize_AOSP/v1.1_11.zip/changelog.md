## Registro de cambios:

-1.1
	Cambiado directorio de /vendor a /product
	
-1.0
	Versión inicial, compatible con Android 8 y superiores
	Probado en Android AOSP, no se garantiza en ROMs altamente personalizadas como Miui
	
---

*ENGLISH VERSION*

---

## Changelog:

-1.1
	Changed directory from /vendor to /product

-1.0
    Initial version, compatible with Android 8 and above
    Tested on Android AOSP, not guaranteed on highly customized ROMs like Miui
