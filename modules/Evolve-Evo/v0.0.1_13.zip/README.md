# Evolve Evo Sans
Evolve Evo Font for Android AOSP roms 

## Preview AOSP Keyboard

<img SRC="https://github.com/Magisk-Modules-Alt-Repo/Evolve-Evo/blob/master/.github/workflows/Screenshot_20220514-082743_Trebuchet.png" />
<img SRC="https://github.com/Magisk-Modules-Alt-Repo/Evolve-Evo/blob/master/.github/workflows/Screenshot_20220514-082800_Trebuchet.png" />
<img SRC="https://github.com/Magisk-Modules-Alt-Repo/Evolve-Evo/blob/master/.github/workflows/Screenshot_20220514-082814_Trebuchet.png" />
<img SRC="https://github.com/Magisk-Modules-Alt-Repo/Evolve-Evo/blob/master/.github/workflows/Screenshot_20220514-082828_Trebuchet.png" />

## Download
get latest build directly from <a href="https://github.com/Magisk-Modules-Alt-Repo/Evolve-Evo/releases/latest">here</a>
