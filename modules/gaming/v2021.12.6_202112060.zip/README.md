##### GAMING乛Mode | Magisk Module

##### Contact: https://t.me/AkiraProjects

##### Disclaimer: Naturally, you take all the responsibility for what happens to your device when you start messing around with things. I (Akira) will not be responsible for ANY damage caused to anyone's devices due to the use of this module.

##### Yes, works on all ROMs and on all firmwares.

##### ✓ INSTALLATION: Just flash via Magisk and reboot

#### - ChangeLog -

### Version Code: 5

- Disabled Thermals
- Disabled Kernel Panic
- Disabled Gesture Vibration
- Disabled Wakelock
- Disabled Debugging
- Enabled TCP Available Congestion Control
- Enabled Sound Boost
- Enabled SQLite Optimisation
- Enabled File System Optimisation
- Enabled System Refresh
- Added Performance Enhancement
- Added Miscellaneous
- Improved Gaming Mode

### Version Code: 4

- Added Performance Related Bulid.prop
- Added New Gaming Mode
- Added Game Unlocker

### Version Code: 3

- Fixed CPU Freq Stuck To Highest

### Version Code: 2

- Added PUBG GL And KR Config
- Added debug.hwui.renderer
- Added ro.opa.eligible_device
- Added CPU Freq Stuck To Highest - Experimental

### Version Code: 1 

- Boost Game Performance When The Game Start
- Improve Touch Sensitivity
- Improve Network And Ping
- Unlock Game Graphics and FPS
