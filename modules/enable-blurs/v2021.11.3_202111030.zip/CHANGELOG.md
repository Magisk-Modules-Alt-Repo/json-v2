# Changelog

### Version 3
* Add code to restart surfaceflinger after final prop applied; this actually allows the blur to show
* Add Action script to re-run late_start code on-demand; turn off `disable_blurs` & restart surfaceflinger

### Version 2
* Fix workflow

### Version 1
* Initial commit