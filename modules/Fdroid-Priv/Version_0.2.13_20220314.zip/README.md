# F-Droid Privileged Extension installer

![Magisk](http://i.imgur.com/WA4LBkF.png)

This is an unofficial installer of the F-Droid Privileged Extension. With the power of Magisk, this is done systemlessly.