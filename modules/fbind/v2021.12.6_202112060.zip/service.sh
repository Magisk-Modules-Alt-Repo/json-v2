#!/system/bin/sh
start-stop-daemon -bx /system/bin/fbind -S -- --service
exit 0
