![Google Sans](https://raw.githubusercontent.com/Magisk-Modules-Alt-Repo/Google-Sans-Magisk/master/Google-Sans.png)
### Google Sans Font Package

- Fully replaces the system font i.e. Roboto -> Google Sans 
- Works on any device running Android 8.0+ and Magisk 20.4+ 
- Bonus! I have included the latest Android 11 leaked emojis 
  as well (Credits to: [@RadekBledowski](https://github.com/RadekBledowski))

![Sample](https://raw.githubusercontent.com/Magisk-Modules-Alt-Repo/Google-Sans-Magisk/master/Sample.png)
