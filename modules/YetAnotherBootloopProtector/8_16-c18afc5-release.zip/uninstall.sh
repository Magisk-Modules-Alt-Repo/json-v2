rm -f "/data/adb/service.d/.status.sh"
