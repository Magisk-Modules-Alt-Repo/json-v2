# v4.7
- Removed unnecessary webui themes
