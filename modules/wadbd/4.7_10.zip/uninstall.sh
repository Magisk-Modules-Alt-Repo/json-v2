[ -f /data/adb/ksu/bin/wadbd ] && rm -f /data/adb/ksu/bin/wadbd
[ -f /data/adb/ap/bin/wadbd ] && rm -f /data/adb/ap/bin/wadbd
