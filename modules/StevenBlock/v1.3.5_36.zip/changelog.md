## 📝Important Notes

- Check out the latest updates in the "releases" section.

- To use the 1hosts list, install 1hosts.zip. For the stevenblack list, install stevenblack.zip.

- Please don't use this module with the AdAway app or the systemless hosts module.

- Make sure your hosts file is up-to-date using any hosts manager or file manager. If it's not, let me know!
