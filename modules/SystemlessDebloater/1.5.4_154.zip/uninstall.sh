#!/system/bin/sh

# Magisk Module: Systemless Debloater v1.5.4
# Copyright (c) zgfg @ xda, 2020-
# Uninstall script by ipdev @ xda-developers

# Remove mountList log file
rm /data/local/tmp/SystemlessDebloater-service.log
