## Systemless Adblocker
Telegram:
https://t.me/burhanverse

## v1.9
- Latest hosts.

## v1.8
- Latest hosts.

## v1.7
- Newly Added: Unified Hosts + fakenews
- Reminder for existing users to update as this will download and apply the latest hosts.

### v1.6
- Initial release for Magisk-Modules-Alt-Repo.
- Include and use curl binary within the module as in case curl is missing in your system.

### v1.5
- Newly Added: Unified Hosts + fakenews + gambling + porn.

### v1.4
- Improve code formating and minor text correction.

### v1.3
- Changed module name to Systemless Adblocker.
- Minor text corrections.

### v1.2
- Newly Added: Unified Hosts + fakenews + gambling.
- Unified Hosts.
- Unified hosts + fakenews + gambling + social.
- Unified hosts + fakenews + gambling + porn + social.
- more will be added soon...

### v1.1
- Simplified the main script logic.
- Made a separate dir for the host installer scripts.

### v1.0
- Added key-selector to switch between different hosts.
- Initial release.
